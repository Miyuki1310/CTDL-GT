public interface ListInterface<E> {
    public void addSortedList(E item, Node<E> curr);
}